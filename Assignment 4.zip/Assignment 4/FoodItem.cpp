#include "FoodItem.h"
#include<iostream>
using namespace std;

/*
  Authors: Braeden Diaz and Arianne Grimes

  Main implementation of a FoodItem object.

 */

// Constructor that takes in a UPC code, shelf life, and name
FoodItem::FoodItem(string upcCode, int shelfLife, string name)
{
  this->upcCode = upcCode;
  this->shelfLife = shelfLife;
  this->name = name;
  this-> quantity = 0;
  this->expiration= 0;
  this->totalRequests = 0;
}

// Returns this FoodItem's UPC Code
string FoodItem::getUPCCode()
{
  return this->upcCode;
}

// Returns this FoodItem's shelf life
int FoodItem::getShelfLife()
{
  return this->shelfLife;
}

// Returns this FoodItem's name
string FoodItem::getName()
{
  return this->name;
}

// Returns this FoodItems time until expiration
int FoodItem::getExpiration()
{
  return this->expiration;
}

// Sets the amount of time until this FoodItem expires
void FoodItem::setExpiration(int date)
{
  this->expiration = date + shelfLife;
}

// Returns this FoodItem's quantity
int FoodItem::getQuantity()
{
  return this->quantity;
}

// Sets this FoodItem's quantity to the provided new quantity
void FoodItem::setQuantity(int newQuantity)
{
  this->quantity = newQuantity;
}

// Return the amount this FoodItem was requested
int FoodItem::getTotalRequests()
{
  return this->totalRequests;
}

// Add more to this FoodItem's requests
void FoodItem::addMoreTotalRequests(int newRequests)
{
  this-> totalRequests = this->totalRequests + newRequests;
}

