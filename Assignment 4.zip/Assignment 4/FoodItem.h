
#ifndef FOOD_ITEM_H
#define FOOD_ITEM_H

#include <string>
#include <queue>

/*
  Authors: Braeden Diaz and Arianne Grimes

  Represents a FoodItem object.

  Each food item is specified on a line that starts with the words 'Food Item'.
  A food item has a UPC code (a single string of number characters of length 
  greater than 0), a shelf life (in days), and a name (a string of words that 
  ends at the end of the line).

 */
class FoodItem
{
 private:
  std::string upcCode; // This FoodItem's unique UPC code
  int shelfLife;       // The shelf life of this FoodItem
  std::string name;    // The name of this FoodItem
  int expiration;      // The amount of time until this FoodItem expires
  int quantity;        // The quantity of this FoodItem
  int totalRequests;   // The amount of times this FoodItem was requested
  
 public:
  FoodItem(std::string upcCode, int shelfLife, std::string name);
  std::string getUPCCode();
  int getShelfLife();
  std::string getName();
  int getExpiration();
  void setExpiration(int date);
  int getQuantity();
  void setQuantity(int newQuantity);
  int getTotalRequests();
  void addMoreTotalRequests(int newRequests);
 
};

#endif
