
#ifndef WAREHOUSE_H
#define WAREHOUSE_H

#include <string>
#include "FoodItem.h"
#include <queue>
#include <map>

/*
  Authors: Braeden Diaz and Arianne Grimes

  Represents a Warehouse object.

  Each warehouse inventory is specified on a line that starts with the word 
  'Warehouse'.  A warehouse has a name (a string of words that ends at the 
  end of the line) that is the name of the city where the warehouse is located. 
 */
class Warehouse
{
 private:
  std::string name;                                       // The name of this Warehouse
  std::map<std::string, std::queue<FoodItem> > inventory; // Main datastructure that represents this Warehouse's inventory

 public:
  Warehouse(std::string name);
  std::string getName();
  void receive(FoodItem food, int quantity, int date);
  void request(std::string upcCode, int quantity);
  void update_inventory(int date);
  std::map<std::string, std::queue<FoodItem> > getInventory();
};

#endif
