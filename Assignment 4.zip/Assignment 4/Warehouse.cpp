#include "Warehouse.h"
#include<iostream>

using namespace std;

/*
  Authors: Braeden Diaz and Arianne Grimes

  Main implementation of a Warehouse object.
 */

// Constructor
Warehouse::Warehouse(string name)
{
  
  this->name = name;
}

// Returns this Warehouse's name
string Warehouse::getName()
{
  return this->name;
}

// Returns this Warehouse's inventory
std::map<std::string, std::queue<FoodItem> >  Warehouse::getInventory()
{
  return this->inventory;
}

/*
  Places the provided FoodItem into this Warehouse's inventory in the amount
  of the provided quantity and sets the expiration date of the FoodItem to
  the provided date.
 */
void Warehouse::receive(FoodItem food, int quantity, int date)
{
  string upcCode = food.getUPCCode();           // Get the UPC code of the FoodItem
  food.setQuantity(quantity);                   // Set the FoodItem's quantity
  food.setExpiration(date);                     // Set the FoodItem's expiration date

  map<string, queue<FoodItem> >::iterator it;   // Creates an iterator

  it = this->inventory.find(upcCode);           // Set the iterator to the FoodItem's queue (shelf) in this inventory
  
  // If the queue (shelf) does not exist, create it, add the FoodItem to it, and
  // add it to this Warehouse's inventory. Otherwise, get the queue (shelf) for the
  // FoodItem and push this quantity of FoodItem into it.
  if(it==inventory.end())
  {
	queue<FoodItem> q;                        // Create a new queue
      
	q.push(food);                             // Push the FoodItem into it


	pair<string, queue<FoodItem> > paired;    // Declare a pair to match the inventory map
      
	paired = make_pair(food.getUPCCode(), q); // Make a pair using the FoodItem's UPC code and the new queue

	this->inventory.insert(paired);           // Insert the pair into this Warehouse's inventory
  }
  else
  {
	it->second.push(food);                    // Push the FoodItem to the already existing queue (shelf)
  }
}

/*
  Removes FoodItems from this Warehouse's inventory.
 */
void Warehouse::request(string upcCode, int quantity)
{
  // Create the iterator
  map<string, queue<FoodItem> >::iterator it;

  // Find the FoodItem with the matching upcCode
  it = this->inventory.find(upcCode);
  
  // If the FoodItem exists, it will not equal the end, otherwise ignore the request
  if (it != inventory.end())
  {
    FoodItem f = it->second.front();           // Get the top (oldest) FoodItem
    
    // While the requested quantity is still unsattisfied, loop through
	// the FoodItems at the top of the queue adjusting their quantities and
	// popping them when they reach zero.
    while (quantity > 0)
	{
	  // If the FoodItem quantity at the top of the queue is greater than
	  // the requested quantity.
	  if (f.getQuantity() > quantity)
	  {
		int tempQuantity = quantity;                   // Temporary variable to hold the quantity as we will be altering it but
		                                               // we don't want it altered when we set the FoodItem's new quantity

        quantity = quantity - f.getQuantity();         // This will become negative thus exiting the loop

		f.setQuantity(f.getQuantity() - tempQuantity); // Set the FoodItem quantity at the top of the queue equal
		                                               // to itself minus the requested quantity
	  }
	  else
	  {
		quantity--;                                // Decrement the requested quantity
		f.setQuantity(f.getQuantity() - 1);        // At the same time, decrement the quantity of the FoodItem at the top of the queue
	  }

	  // If the FoodItem at the top of the queue has a quantity of zero, then we
	  // pop it from the queue and set f equal to the next FoodItem on the queue and
	  // continue looping.
	  if (f.getQuantity() == 0)
	  {
		it->second.pop();                          // Pop the top (oldest) FoodItem from the queue

		// After popping, if the queue size is zero, erase it from the inventory
        if (it->second.size() == 0)
		{
		  this->inventory.erase(upcCode);
		  break;
	    }

		f = it->second.front();                    // Set f to the next FoodItem on the queue
	  }
	}
  }
}

/*
  Loop through this warehouse's inventory and compare its FoodItem's expiration date to
  the current date. If they are equal, we remove the food item from its queue. Do this
  for all the FoodItem queues in the inventory.

  Invariant: The oldest FoodItem is always at the top of its queue
 */
void Warehouse::update_inventory(int date)
{
  for (map<string, queue<FoodItem> >::iterator it = this->inventory.begin(); it != this->inventory.end(); it++)
  {
    // Loops through a single FoodItem queue and compares the expiration date to the current date
    while (it->second.front().getExpiration() == date)
	{
	  it->second.pop();

      // If the size of the queue becomes empty, we remove it from the inventory and break out
      // of this while loop and move on to the next queue in the inventory.
	  if (it->second.size() == 0)
	  {
		this->inventory.erase(it->first);
		break;
	  }
	}
  }
}
