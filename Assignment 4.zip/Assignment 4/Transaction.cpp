#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <map>
#include <cstdlib>
#include <sstream>
#include"FoodItem.h"
#include "Warehouse.h"

using namespace std;

/*
  Authors: Braeden Diaz and Arianne Grimes

  Main class used to conduct transactions (Receives and Requests) between
  FoodItems and Warehouses.
 */

// Forward Declarations
vector<string> read_in_file(char* filename);
void request(string upcCode, string quantity, string warehouseName, map<string,Warehouse> *warehouses);
void receive (string upcCode, string quantity, string warehouseName, map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItems, int date);
void updateInventory(map<string, Warehouse>  *warehouses, int date);
void report(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItems);
void findMostPopularProducts(map <string, FoodItem>  *foodItems);
void findNotExistProducts(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItem);
void findOverstockProducts(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodIte);

// Main function that parses the data file and calls the appropriate functions
int main(int argc, char** argv)
{
  // Read in all the lines from the provided file in the arguments parameter into a string vector
  vector<string> data = read_in_file(argv[1]);

  // Main Data structures that keep of track of all Warehouses and FoodItems in this Transaction
  map<string, FoodItem> foodItems;
  map<string, Warehouse> warehouses;

  //keep track of what day we are on 
  int date = 0; 

  // Loop through all of the lines in the string vector and parse them accordingly
  for (int i = 0; i < data.size(); i++)
  {
	if (data[i].find("FoodItem") != string::npos) // Parse the FoodItem lines to get the FoodItem parameters
	{
	  // Parse the FoodItem line
	  string upcCode = data[i].substr(data[i].find("Code:") + 6, 10);
	  string shelfLife = data[i].substr(data[i].find("life:") + 6, data[i].find("Name:") - data[i].find("life:") - 8);
	  string name = data[i].substr(data[i].find("Name:") + 6);

	  // Create the FoodItem objects and store them in its map
	  FoodItem newFoodItem(upcCode, atoi(shelfLife.c_str()), name);
	  foodItems.insert(pair<string, FoodItem>(upcCode, newFoodItem));
	}
	else if (data[i].find("Warehouse") != string::npos) // Parse the Warehouse lines to get their names
	{
	  // Parse the warehouse name
	  string name = data[i].substr(data[i].find("-") + 2);

	  // Create the Warehouse objects and store them in its map
	  Warehouse newWarehouse(name);

	  // Insert the new warehouse into the warehouses map
	  warehouses.insert(pair<string, Warehouse>(name, newWarehouse));
	}
	else if (data[i].find("Start date") != string::npos) // Parse the "Start date" line to get the starting date of the transaction
	{
	  // Parse the start date (if required)
	  string startDate = data[i].substr(data[i].find("date:") + 6);	  
	}
	else if (data[i].find("Receive") != string::npos) // Parse the "Receive" lines to get the receive parameters
	{
	  // Parse the receive line
	  string upcCode = data[i].substr(data[i].find(":") + 2, 10);
	  string quantity = data[i].substr(data[i].find(":") + 13, data[i].rfind(" ") - 20);
	  string warehouseName = data[i].substr(data[i].find(":") + 15);

	  receive(upcCode, quantity, warehouseName,  &warehouses, &foodItems, date);
	}
	else if (data[i].find("Request") != string::npos) // Parse the "Request" lines to get the request parameters
	{
	  // Parse the request line
	  string upcCode = data[i].substr(data[i].find(":") + 2, 10);
	  string quantity = data[i].substr(data[i].find(":") + 13, data[i].rfind(" ") - 20);
	  string warehouseName = data[i].substr(data[i].find(":") + 15);
	  
	  request(upcCode, quantity, warehouseName, &warehouses);

	  // Count Requests
	  int foodQuantity;
	  istringstream(quantity) >> foodQuantity;
	  FoodItem &food = foodItems.find(upcCode)->second;
	  food.addMoreTotalRequests(foodQuantity);
	}
	else if (data[i].find("Next day") != string::npos) // Parse the next day line so that we know when it is the next day
	{
	  // Increment day counter 
	  date++;
	  updateInventory(&warehouses, date);;
	}
	else if (data[i].find("End") != string::npos) // Parse the final end line
	{
	  // Do nothing
	}
  }
  
  report(&warehouses, &foodItems);

  return 0;
}

//Reads in the text from the file with the provided filename
vector<string> read_in_file(char* filename)
{
  ifstream file;                     // Create a filestream
  
  file.open(filename);               // Open the provided file

  vector<string> fileDataLines;      // Vector that will hold each line of the provided file

  // While the end of the file hasn't been reached, continue to read in lines from the file
  while (!file.eof())
  {
	string line;
	getline(file, line);             // Get a single line from the file

	// If the line contains nothing (usually the very last line) simply break, otherwise
	// add the line to the fileData string followed by a newline character
	if (line == "")
	{
	  break;
	}
	else
	  fileDataLines.push_back(line);
  }

  return fileDataLines;
}

// Processes request lines
void request(string upcCode, string quantity, string warehouseName, map<string,Warehouse> *warehouses)
{
  int foodQuantity;
  istringstream(quantity) >> foodQuantity;                  // Convert the provided quantity to an integer

  Warehouse  &w = warehouses->find(warehouseName)->second;  // Get the Warehouse corresponding to the provided name

  w.request(upcCode, foodQuantity);                         // Use the Warehouse's request function to request the FoodItem
}

void receive (string upcCode, string quantity, string warehouseName, map<string, Warehouse> *warehouses, map <string, FoodItem> *foodItems, int date)
{
  int foodQuantity;
  istringstream(quantity) >> foodQuantity;                    // Convert the provided quantity to an integer

  FoodItem food = foodItems->find(upcCode)->second;           // Get the FoodItem in this Transaction's map of FoodItems
  Warehouse &ware = warehouses->find(warehouseName)->second;  // Get the Warehouse in this Transaction's map of Warehouses
 
  ware.receive(food, foodQuantity, date);                     // Use the Warehouse's receive function to place a new FoodItem into its inventory
}

// Update each warehouse's inventory based on the new date provided
void updateInventory(map<string, Warehouse>  *warehouses, int date)
{
  // Loop through each warehouse and update its inventory according to the new date
  for (map<string, Warehouse>::iterator it = warehouses->begin(); it != warehouses->end(); it++)
  {
    Warehouse &ware = it->second;
    ware.update_inventory(date);
  }
}

/* Generate the main report for this Transaction
 */
void report(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItems){

  //print report title
  cout<<"Report by Braeden Diaz and Arianne Grimes"<<endl;
  cout<<endl;
  
  //print Unstocked products, call helper method
  cout<<"Unstocked Products:"<<endl;
  findNotExistProducts(warehouses, foodItems);
  cout<<endl; 


  //print well-stocked products, call helper method
  cout<<"Well-Stocked Products:"<<endl;
  findOverstockProducts(warehouses, foodItems);
  cout<<endl;
  
  //print most popular products, call helper method
  cout<<"Most Popular Products:"<<endl;
  findMostPopularProducts(foodItems);
  findMostPopularProducts(foodItems);
  findMostPopularProducts(foodItems);
  cout<<endl;

}

/* Find the most popular products (FoodItems)
 */
void findMostPopularProducts(map <string, FoodItem>  *foodItems){

  //check that foodItems map contains something
  if(foodItems->size()>0){

    //store upcCode and requests (the most popular so far)
    string greatestSoFarUpc= "";
    int greatestSoFarRequests = 0;;

    //iterate over foodItems
    for(map<string, FoodItem>::iterator it = foodItems->begin(); it != foodItems->end(); it++){

      //check if we have found a larger number of requests than what we have stored
      if(greatestSoFarRequests < it->second.getTotalRequests()){

	//store new largest
	greatestSoFarRequests = it->second.getTotalRequests();
	greatestSoFarUpc = it->second.getUPCCode();
      }
    
    }

    //find the name of the foodItem that coresponds to the upc
  FoodItem &food = foodItems->find(greatestSoFarUpc)->second;
  
  //print the most popular foodItem
  cout<<greatestSoFarUpc<<" "<<food.getName()<<endl;
  

  //remove the most popular foodItem from map of foodItems
  foodItems->erase(greatestSoFarUpc);
  
  }
}

/* Find the products (FoodItems) not located in any Warehouse
 */
void findNotExistProducts(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItems){

  //iterate over foodItems
for(map<string, FoodItem>::iterator foodIt = foodItems->begin(); foodIt != foodItems->end(); foodIt++){
  
      //get foodItem
      FoodItem &food = foodIt->second;

      //boolean keeps track if foodItem has been found
      bool found = false;

      //iterate over warehouses
      for(map<string, Warehouse>::iterator wareIt = warehouses->begin();wareIt != warehouses->end(); wareIt++){

	//get warehouse
	Warehouse &ware = wareIt->second;
	const map<string, queue<FoodItem> > &inventory = ware.getInventory();
    
	//look for foodItem, mark with bool if found
	if(inventory.find(food.getUPCCode()) != inventory.end()){
	  found = true ;
	 
	  break;
	}
     
      }
      
      //if not found, print
      if (!found){
	cout<<food.getUPCCode()<<" "<<food.getName()<<endl;
      }
  }
}

/* Find the products (FoodItems) located in multiple Warehouses.
 */
void findOverstockProducts(map<string, Warehouse>  *warehouses, map <string, FoodItem>  *foodItems){

  //iterate over foodItems map
for(map<string, FoodItem>::iterator foodIt = foodItems->begin(); foodIt != foodItems->end(); foodIt++){

      //get foodItem
      FoodItem &food = foodIt->second;

      //set booleans: foundOne for first warehouse the food is found in
      // foundTwo for the second warehouse the food is found in 
      bool foundOne = false;
      bool foundTwo = false;
      
      //iterate over warehouses
      for(map<string, Warehouse>::iterator wareIt = warehouses->begin();wareIt != warehouses->end(); wareIt++){

	//get warehouse
	Warehouse &ware = wareIt->second;
	const map<string, queue<FoodItem> > &inventory = ware.getInventory();
    
	//look for foodItem
	if(inventory.find(food.getUPCCode()) != inventory.end()){

	  //mark with bool if found
	  if(!foundOne){
	   
	    foundOne = true;
	  }
	  else{
	   
	    foundTwo = true;
	  }
	}
     
      }
     
      //print if found twice
      if (foundOne && foundTwo){

	cout<<food.getUPCCode()<<" "<<food.getName()<<endl;
      }
  }
}
